# Chummer ADR Index

Approved architecture decisions for cross-repo Chummer design live here.

## Accepted

- [ADR-0001](ADR-0001-contract-plane-canon.md): Contract-plane canon is package-owned and design-first.
- [ADR-0002](ADR-0002-play-split-ownership.md): `chummer6-mobile` owns the play shell and depends only on approved shared packages.
- [ADR-0003](ADR-0003-ui-kit-split.md): `chummer6-ui-kit` is the package-only shared UI boundary.
- [ADR-0004](ADR-0004-hub-registry-split.md): `chummer6-hub-registry` owns registry and publication state after extraction from run-services.
- [ADR-0005](ADR-0005-desktop-auto-update-plane.md): Desktop auto-update is registry-backed, UI-applied, and atomic in its first public wave.
