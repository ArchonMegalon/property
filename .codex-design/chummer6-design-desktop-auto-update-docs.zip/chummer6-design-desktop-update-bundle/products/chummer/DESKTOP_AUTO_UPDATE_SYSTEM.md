# Desktop auto-update system

## Purpose

This file defines how installable desktop clients become self-updating without collapsing current ownership boundaries.

The target experience is:

- a user installs Chummer from a Windows `.exe` or a macOS `.dmg`
- the desktop client can later check for updates in-app
- the client can download, stage, apply, and relaunch into a newer version
- release channels, promoted heads, rollout state, and revocation truth remain registry-owned
- the updater stays atomic in its first wave so app/runtime skew does not become a hidden source of corruption

## Non-goals

This file does not define:

- mobile/PWA update policy
- store-managed update channels such as MSIX/App Installer or App Store distribution
- a requirement to use any one third-party updater backend forever
- runtime-bundle-only updates in the first wave
- Fleet or Hub as the runtime source of update truth for the client

## Canonical terms

### Desktop head
A ship-ready desktop client flavor keyed by at least:

- `head_id`
- `platform`
- `arch`
- `channel`
- `version`

This model is intentionally head-agnostic. It does not force canon to pick Avalonia versus any other desktop shell ahead of time.

### Install media
A human-facing first-install artifact such as:

- Windows installer `.exe`
- macOS `.dmg`

### Machine update payload
A client-facing staged-update artifact used for in-place application updates. This may be a full package in phase 1 and may later gain delta variants.

### Desktop release head
The registry-owned promoted record for one `head × platform × arch × channel` target. It points at the current install media, current machine update payload, embedded runtime-bundle head, release notes, rollout posture, and revoke state.

### Apply helper
A UI-owned process that performs the actual file replacement, rollback-window bookkeeping, and relaunch sequence after the user approves or the policy allows an update.

### Rollout posture
Registry-owned promotion state for a desktop release head. Minimum first-wave states are:

- `open`
- `paused`
- `revoked`

## Canonical split

### `chummer6-design`
Owns:
- updater architecture canon
- ownership rules
- milestone truth
- contract-family registration
- rollout and non-goal boundaries

Must not own:
- updater code
- packaging scripts
- feed-serving runtime code

### `chummer6-ui`
Owns:
- updater client behavior inside desktop heads
- local install identity and pinned-channel state
- check/download/stage/apply/relaunch UX
- apply helper binaries and platform-specific file-replacement logic
- local rollback-window bookkeeping
- local update logs
- packaging recipes that emit machine update payloads

Must not own:
- promoted channel truth
- published feed vocabulary
- rollout/revoke truth
- compatibility truth for shipped heads once promoted

### `chummer6-hub-registry`
Owns:
- desktop release heads
- machine update payload metadata
- install media metadata
- update-feed projections
- release-note references used by downloads/update surfaces
- embedded runtime-bundle references
- rollout, pause, and revoke truth
- shipped-head compatibility truth

Must not own:
- client polling loops
- apply helpers
- installer build execution

### `fleet`
Owns:
- build matrix expansion
- sign/notarize/publish orchestration
- promotion evidence
- verify gates before promotion
- emergency revoke job orchestration

Must not own:
- runtime feed authority for clients
- updater UX
- local install state

### `chummer6-hub`
Owns:
- registry-backed download/install pages
- account-aware "which channel should I install?" guidance
- optional entitlement brokering for gated channels

Must not own:
- public update-feed truth
- client-side update polling
- client-side apply decisions

### `chummer6-core`
Owns:
- the runtime bundle embedded into a promoted desktop head
- compatibility facts needed to describe that embedded runtime

Must not own:
- desktop update packaging
- desktop feed metadata

## Data and contract rule

Any cross-repo DTOs required for desktop update publication or consumption belong in `Chummer.Hub.Registry.Contracts`.

The first contract family should cover:

- desktop release heads by `head × platform × arch × channel`
- install media references
- machine update payload references
- embedded runtime-bundle references
- release-note references
- rollout/pause/revoke state
- minimum supported updater protocol version
- optional downgrade/rollback policy fields

The UI repo may keep richer local state machines and helper-internal structs, but it may not invent a second promoted-channel vocabulary.

## Artifact model

### Human install media

User-facing initial install artifacts remain distinct from machine update payloads.

Minimum first-wave media:
- Windows installer `.exe`
- macOS `.dmg`

These are discoverable from Hub and other public download surfaces through registry-owned projections.

### Machine update payloads

The updater consumes machine update payloads. The first wave should prefer full-head payloads that replace the shipped app as one atomic unit.

A payload must be sufficient to:

- verify target version and target head
- verify digest/signature before apply
- identify the embedded runtime-bundle head
- stage and apply without consulting Fleet
- relaunch the correct desktop executable or app bundle

### Runtime relationship

Phase 1 desktop auto-update is atomic:
- app shell and embedded runtime bundle move together
- no runtime-only update path is public
- compatibility truth is computed and stored against the shipped head

Later differential or runtime-only evolution requires explicit milestone closure and contract updates.

## Install-state rule

The install root must be replaceable. User content must not depend on mutable files living inside the shipped app payload.

Desktop updater implementation should assume:

- the install root can be replaced
- user data, caches, logs, and preferences live outside the install root
- update staging and rollback metadata live outside the install root or in a replace-safe hidden area

## Client lifecycle

### 1. Check
The desktop client checks the registry-owned feed for its pinned `head/platform/arch/channel`.

Minimum user-facing behavior:
- manual "Check for updates"
- startup or periodic passive checks
- clear channel and version display in settings/about

### 2. Download
If a newer compatible promoted head exists, the client downloads the machine update payload and verifies:

- registry-published digest
- registry-signature or equivalent Chummer-side authenticity proof
- platform code-signing/notarization expectations where applicable

### 3. Stage
The client stages the payload into a replace-safe location and records local state:

- current version
- target version
- pinned channel
- payload digest
- staging path
- backup/rollback candidate if one exists

### 4. Apply
The main app hands off to a UI-owned apply helper.

The apply helper:
- closes the app cleanly
- swaps the install root or app bundle
- preserves external user data
- records an `awaiting_commit` state
- relaunches the new version

### 5. Commit
After the new version reaches first successful launch, the app writes a local commit marker. Only then may the helper discard the immediately previous version.

### 6. Recover
If apply fails or the new version cannot commit cleanly, the client may:
- roll back to the last known good version
- mark the head as failed locally
- stop retrying automatically until user or feed state changes

Local failure does not alter registry truth. Registry truth changes only through promotion/revoke flows.

## Platform notes

### Windows
The preferred first-wave shape is:
- user installs via signed `.exe`
- updater uses a UI-owned apply helper for in-place replacement
- no long-running Windows service becomes required

The first-wave Windows updater should work for per-user installs under a replace-safe application root.

### macOS
The preferred first-wave shape is:
- user installs from a notarized `.dmg`
- updater consumes a signed machine update payload rather than remounting the original DMG
- the apply helper replaces the `.app` bundle using OS-appropriate move/replace semantics

If the installed location is not writable, the helper may escalate through standard macOS authorization or fall back to a guided reinstall flow. Hub must not become the runtime update authority merely to bridge platform friction.

## Security rules

### Trust chain
Desktop auto-update requires all of:
- TLS transport
- registry-owned digest/signature truth
- platform code signing where applicable
- notarization where applicable for macOS public releases

### Channel pinning
A client is pinned to one channel until the user or a governed product flow changes it. Silent cross-channel jumps are forbidden.

### Anti-downgrade
The client must not auto-apply a lower version unless:
- the registry explicitly marks a governed rollback target
- the local UI presents that rollback as an explicit recovery path

### Public channel auth
Public channels must be readable without a Hub account session.

Private or entitlement-gated channels may require Hub-brokered authorization, but the final answer to "what is the current head?" still comes from registry-owned channel records.

### No hidden background authority
The updater must not require Fleet or Hub to stay online as a conversational orchestrator during apply. Once the payload and local metadata are staged, apply is a local UI-owned operation.

## Rollout, revoke, and rollback

### Rollout
The registry may expose gradual rollout posture, but the minimal canonical states are still:

- `open`
- `paused`
- `revoked`

### Revoke
If a promoted head is revoked:
- the registry marks it revoked
- clients stop auto-applying it
- clients may surface a warning if already running it
- Fleet may orchestrate emergency publication of a replacement head

### Rollback
Rollback is local recovery, not a hidden second release train.

First-wave rule:
- keep one last-known-good version available until commit
- after commit, normal rollback is explicit and exceptional
- registry may later expose governed rollback targets, but clients must not improvise downgrade policy

## Observability and privacy

The updater may keep a local anonymous install identifier and local logs for troubleshooting.

It must not require:
- sign-in
- hosted memory state
- raw provider credentials
- hidden background telemetry to complete a normal public-channel update

Aggregated install/update counts or health projections belong in registry read models, not in client-invented side channels.

## Implementation shape by repo

### `chummer6-ui`
Recommended internal shape:

- one UI-local updater runtime assembly such as `Chummer.Desktop.Update` or an expansion of `Chummer.Desktop.Runtime`
- one small apply-helper executable
- one `IRegistryUpdateClient` adapter consuming `Chummer.Hub.Registry.Contracts`
- per-head startup hooks and settings/about surfaces in the desktop entrypoints

The updater backend is not canonical. Chummer may implement the UI-owned updater through a wrapped third-party framework or a custom helper, provided the ownership split and feed vocabulary remain intact.

### `chummer6-hub-registry`
Required shape:
- contract-family additions in `Chummer.Hub.Registry.Contracts`
- persisted release-head/update-payload metadata
- feed projections for public and optionally gated channels
- revoke and rollout state in registry truth

### `fleet`
Required shape:
- publish/sign/notarize orchestration for install media and update payloads
- promotion evidence recorded before registry head moves
- emergency revoke or replacement waves that still land through registry truth

### `chummer6-hub`
Required shape:
- `/downloads` and related surfaces render desktop release-head truth from registry
- signed-in install guidance may broker gated-channel access
- Hub never becomes the canonical feed host

## Sequencing

1. Establish canon and milestone truth.
2. Add registry contracts and persisted desktop release heads.
3. Ship Windows self-update through a UI-owned apply helper.
4. Ship macOS self-update through a UI-owned apply helper.
5. Add rollout/revoke/rollback discipline.
6. Only then consider delta updates or runtime-only evolution.

## Acceptance bar

The desktop auto-update lane is not "done" merely because a feed exists.

It is done when:

- registry-owned desktop heads are the only promoted update truth
- Windows and macOS desktop clients can check, stage, apply, and relaunch
- update failures have a local recovery path
- public channels work without sign-in
- runtime/app skew is prevented by the atomic first-wave rule
- Hub, Fleet, and helper scripts do not become shadow feed authorities
