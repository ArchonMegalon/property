# Ownership matrix

## Summary table

| Repo | Primary mission | Owns | Must not own | Key package(s) |
| --- | --- | --- | --- | --- |
| `chummer6-design` | central design governance | canon, ownership, milestones, blockers, sync, review guidance | code implementation, hidden parallel product docs | none |
| `chummer6-core` | deterministic rules/runtime engine | engine truth, reducer truth, runtime bundles, runtime fingerprints, explain canon, engine contracts | play UI, workbench UI, registry persistence, media execution, hosted orchestration | `Chummer.Engine.Contracts` |
| `chummer6-ui` | workbench/browser/desktop UX | builders, inspectors, compare, explain UX, admin/moderation UX, desktop packaging, installer/updater recipes, updater client behavior, local install state, staged apply helpers | play shell, rule evaluation, offline ledger, registry rollout truth, canonical channel/update-feed truth, media execution | consumes `Chummer.Engine.Contracts`, `Chummer.Ui.Kit` |
| `chummer6-mobile` | live session/mobile/PWA shell | player shell, GM shell, offline ledger, sync client, play-safe Coach/Spider surfaces | builder UX, rule evaluation, registry/moderation, provider secrets | consumes `Chummer.Engine.Contracts`, `Chummer.Play.Contracts`, `Chummer.Ui.Kit` |
| `chummer6-hub` | hosted orchestration and community plane | identity, user accounts, groups, memberships, ledgers, participation UX, relay, approvals, memory, Coach/Spider/Director orchestration, delivery, play API aggregation, registry-backed downloads UX, account-aware install guidance | duplicate mechanics, registry persistence after split, media rendering after split, raw participant auth caches, Fleet worker execution, release manifest generation truth, update-feed truth | `Chummer.Play.Contracts`, `Chummer.Run.Contracts` |
| `chummer6-ui-kit` | shared design system | tokens, themes, shell primitives, accessibility primitives, reusable components | domain DTOs, HTTP clients, storage, rules math | `Chummer.Ui.Kit` |
| `chummer6-hub-registry` | catalog/publication service | artifacts, publication drafts, release channels, desktop release heads, installs, update feeds, rollout/revocation state, reviews, compatibility, runtime-bundle heads | relay, Coach/Spider, media rendering, client UX, installer build execution | `Chummer.Hub.Registry.Contracts` |
| `chummer6-media-factory` | media execution plant | render jobs, previews, manifests, asset lifecycle, provider adapters, signed asset access | campaign truth, rules truth, approvals policy, player/client UX | `Chummer.Media.Contracts` |
| `fleet` | execution/control plane | worker orchestration, queue policy, review/landing control, cheap-first automation, explicit premium burst lanes, lane-local auth helpers, sponsor-session receipts, release orchestration, signing/notarization jobs, publish/signoff evidence | product truth, contract canon, session truth, user/group/ledger truth, raw hosted identity/auth storage, installer recipe truth, canonical release-channel truth | none |
| `chummer5a` | legacy oracle | migration fixtures, regression corpus, legacy compatibility reference | vNext architecture ownership | none |

## Boundary notes

### `chummer6-core`
The only repo allowed to define canonical mechanics truth.

### `chummer6-ui`
The only repo allowed to define workbench/browser/desktop product UX. It is also the only repo allowed to own desktop updater client behavior, local update state, and staged apply helpers. It is not allowed to redefine published channel truth.

### `chummer6-mobile`
The only repo allowed to define the dedicated live play/mobile shell.

### `chummer6-hub`
The only repo allowed to own the reusable community/accounting plane and hosted orchestration, but not the only repo allowed to own hosted services. Registry and media must remain separate service boundaries. Hub may explain install/update posture, but it does not become the feed authority.

### `chummer6-ui-kit`
The only repo allowed to own shared cross-head UI primitives.

### `chummer6-hub-registry`
The only repo allowed to own immutable artifact catalog, publication/install/update truth, promoted release channels, and desktop release heads.

### `chummer6-media-factory`
The only repo allowed to own render execution and render-asset lifecycle.

### `fleet`
The only adjacent repo allowed to own cross-repo worker scheduling, release orchestration, participant worker lifecycle, and landing control, but never canonical Chummer product truth.
