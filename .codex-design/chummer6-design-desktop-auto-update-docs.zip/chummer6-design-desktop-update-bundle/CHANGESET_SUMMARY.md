# Proposed Chummer6 Design Change Set: Desktop Auto-Update

This bundle adds a first-class desktop auto-update design for Windows and macOS and updates the surrounding canon so the feature lands inside the existing ownership model.

## New canonical docs

- `products/chummer/DESKTOP_AUTO_UPDATE_SYSTEM.md`
- `products/chummer/adrs/ADR-0005-desktop-auto-update-plane.md`

## Updated canonical docs

- `products/chummer/README.md`
- `products/chummer/RELEASE_PIPELINE.md`
- `products/chummer/ROADMAP.md`
- `products/chummer/OWNERSHIP_MATRIX.md`
- `products/chummer/CONTRACT_SETS.yaml`
- `products/chummer/PROGRAM_MILESTONES.yaml`
- `products/chummer/projects/ui.md`
- `products/chummer/projects/hub-registry.md`
- `products/chummer/projects/hub.md`
- `products/chummer/adrs/README.md`
- `products/chummer/sync/sync-manifest.yaml`

## Design spine

- UI owns updater client behavior, local install state, staging, apply helpers, and relaunch flow.
- Registry owns promoted desktop release heads, machine update payload metadata, rollout/pause/revoke truth, and compatibility projections.
- Fleet owns build/sign/notarize/promote orchestration and evidence.
- Hub owns download/install guidance and optional gated-channel brokering, but not public update-feed truth.
- Phase 1 is atomic: the desktop app and its embedded runtime bundle update together.

## Recommended implementation shape

Inside `chummer6-ui`, add a UI-local update runtime plus a small apply helper. Consume desktop release-head/update-feed DTOs from `Chummer.Hub.Registry.Contracts`. Keep any third-party updater backend behind Chummer-owned adapters so the package/feed vocabulary and ownership split stay canonical even if the underlying backend changes later.
